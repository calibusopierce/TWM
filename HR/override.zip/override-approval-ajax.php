<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/TWM/includes/nav.php'; // defines base_url()
require_once __DIR__ . '/../auth_check.php';
require_once __DIR__ . '/../RBAC/rbac_helper.php';
require_once __DIR__ . '/../test_sqlsrv.php'; // establishes $conn / $pdo
auth_check();

header('Content-Type: application/json');

// ASSUMPTION (please confirm): new RBAC module key for this page, following
// the same pattern as leave_application / leave_management being two keys
// for one feature. If you'd rather this reuse the existing
// 'override_attendance' key with a role check, let me know and I'll swap
// rbac_gate()/rbac_enforce_full_access() calls below accordingly.
rbac_gate($pdo, 'override_attendance_approval');

function opa_fmt_time($v): string {
    if ($v === null || $v === '') return '';
    if ($v instanceof DateTime) return $v->format('h:i A');
    $ts = strtotime($v);
    return $ts !== false ? date('h:i A', $ts) : (string)$v;
}

// 24-hour 'H:i' for populating an <input type="time"> in the edit modal.
function opa_fmt_time24($v): string {
    if ($v === null || $v === '') return '';
    if ($v instanceof DateTime) return $v->format('H:i');
    $ts = strtotime($v);
    return $ts !== false ? date('H:i', $ts) : '';
}

function opa_fmt_date($v): string {
    if ($v === null || $v === '') return '';
    if ($v instanceof DateTime) return $v->format('m/d/Y');
    $ts = strtotime($v);
    return $ts !== false ? date('m/d/Y', $ts) : (string)$v;
}

function opa_fmt_datetime($v): string {
    if ($v === null || $v === '') return '';
    if ($v instanceof DateTime) return $v->format('m/d/Y h:i A');
    $ts = strtotime($v);
    return $ts !== false ? date('m/d/Y h:i A', $ts) : (string)$v;
}

// The employee/user ID of the HR reviewer taking the action — stored back
// into HR_EmployeeID so approvals/rejections/edits are attributable.
// Same ASSUMPTION as override-attendance-ajax.php: $_SESSION['EmployeeID']
// is unconfirmed against the real login script. Falling back to UserID
// (cast to string) if EmployeeID isn't present in session.
function opa_reviewer_id(): string {
    $eid = trim($_SESSION['EmployeeID'] ?? '');
    if ($eid !== '') return $eid;
    return trim((string)($_SESSION['UserID'] ?? ''));
}

// A submission can now carry a point correction (ShiftPart/Direction/ATime),
// a full-shift schedule (SetTime*), or both at once — the form on
// override-attendance.php writes only whichever the employee filled in.
// Looked up server-side rather than trusted from the client, since which
// columns get written by update/approve/reject depends on it.
function opa_row_kind($conn, int $id): ?array {
    $stmt = sqlsrv_query($conn, "SELECT [ShiftPart], [Direction], [SetTime], [SetTimeOutAM], [SetTimeInPM], [SetTimeOutPM] FROM [dbo].[TBL_Attendance_Override] WHERE [ID] = ?", [$id]);
    if ($stmt === false) return null;
    $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    if (!$row) return null;
    $hasCorrection = trim($row['ShiftPart'] ?? '') !== '' || trim($row['Direction'] ?? '') !== '';
    $hasSchedule = $row['SetTime'] !== null || $row['SetTimeOutAM'] !== null
        || $row['SetTimeInPM'] !== null || $row['SetTimeOutPM'] !== null;
    $kind = $hasCorrection && $hasSchedule ? 'mixed' : ($hasCorrection ? 'time' : 'schedule');
    return ['kind' => $kind, 'hasCorrection' => $hasCorrection, 'hasSchedule' => $hasSchedule];
}

$action = $_GET['action'] ?? '';

if ($action === 'get_overrides') {

    $status = $_GET['status'] ?? '0'; // '0' Pending, '1' Approved, '2' Rejected
    if (!in_array($status, ['0', '1', '2'], true)) {
        echo json_encode(['success' => false, 'message' => 'Invalid status filter.']);
        exit;
    }

    // Override_Type on TBL_Attendance_Override stores Tbl_Override_Type.TypeID
    // as text (see override-attendance.php's save_override, which writes the
    // <select> value straight through) — cast TypeID to compare/join.
    $sql = "SELECT
                o.[ID], o.[EmployeeID], o.[ADate], o.[OriginalTime], o.[ATime],
                o.[Direction], o.[ShiftPart], o.[Remarks],
                o.[SetTime], o.[SetTimeOutAM], o.[SetTimeInPM], o.[SetTimeOutPM],
                o.[Override_Type], o.[HR_Status], o.[HR_EmployeeID], o.[HR_Approved_DateTimeInput],
                o.[UserInput], o.[DateTimeInput],
                e.[FirstName], e.[MiddleName], e.[LastName], e.[Department],
                t.[Type_Name], t.[Category] AS TypeCategory
            FROM [dbo].[TBL_Attendance_Override] o
            LEFT JOIN [dbo].[TBL_HREmployeeList] e ON e.[EmployeeID] = o.[EmployeeID]
            LEFT JOIN [dbo].[Tbl_Override_Type] t ON CAST(t.[TypeID] AS NVARCHAR(50)) = o.[Override_Type]
            WHERE o.[HR_Status] = ?
            ORDER BY o.[DateTimeInput] DESC";

    $stmt = sqlsrv_query($conn, $sql, [(int)$status]);

    if ($stmt === false) {
        echo json_encode(['success' => false, 'message' => 'Query error.', 'errors' => sqlsrv_errors()]);
        exit;
    }

    $statusLabels = [0 => 'Pending', 1 => 'Approved', 2 => 'Rejected'];

    $rows = [];
    while ($r = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $mid  = trim($r['MiddleName'] ?? '');
        $mi   = $mid !== '' ? mb_substr($mid, 0, 1) . '. ' : '';
        $name = trim(($r['FirstName'] ?? '') . ' ' . $mi . ($r['LastName'] ?? ''));

        $hasCorrection = trim($r['ShiftPart'] ?? '') !== '' || trim($r['Direction'] ?? '') !== '';
        $hasSchedule = $r['SetTime'] !== null || $r['SetTimeOutAM'] !== null
            || $r['SetTimeInPM'] !== null || $r['SetTimeOutPM'] !== null;
        $kind = $hasCorrection && $hasSchedule ? 'mixed' : ($hasCorrection ? 'time' : 'schedule');

        $row = [
            'ID'                  => (int)$r['ID'],
            'EmployeeID'          => trim($r['EmployeeID'] ?? ''),
            'EmployeeName'        => $name !== '' ? $name : trim($r['EmployeeID'] ?? ''),
            'Department'          => trim($r['Department'] ?? ''),
            'Date'                => opa_fmt_date($r['ADate']),
            'Kind'                => $kind,
            'ShiftPart'           => trim($r['ShiftPart'] ?? ''),
            'Direction'           => trim($r['Direction'] ?? ''),
            'OriginalTime'        => opa_fmt_time($r['OriginalTime']),
            'CorrectedTime'       => opa_fmt_time($r['ATime']),
            'CorrectedTime24'     => opa_fmt_time24($r['ATime']), // for <input type="time"> in modal
            'ScheduleAmIn'        => opa_fmt_time($r['SetTime']),
            'ScheduleAmIn24'      => opa_fmt_time24($r['SetTime']),
            'ScheduleAmOut'       => opa_fmt_time($r['SetTimeOutAM']),
            'ScheduleAmOut24'     => opa_fmt_time24($r['SetTimeOutAM']),
            'SchedulePmIn'        => opa_fmt_time($r['SetTimeInPM']),
            'SchedulePmIn24'      => opa_fmt_time24($r['SetTimeInPM']),
            'SchedulePmOut'       => opa_fmt_time($r['SetTimeOutPM']),
            'SchedulePmOut24'     => opa_fmt_time24($r['SetTimeOutPM']),
            'OverrideTypeID'      => trim($r['Override_Type'] ?? ''),
            'OverrideType'        => trim($r['Type_Name'] ?? ''),
            'OverrideCategoryRaw' => trim($r['TypeCategory'] ?? ''), // hedge-matched against category ID/name, same as override-attendance.php
            'Remarks'             => trim($r['Remarks'] ?? ''),
            'Status'              => $statusLabels[(int)($r['HR_Status'] ?? 0)] ?? 'Pending',
            'ReviewedBy'          => trim($r['HR_EmployeeID'] ?? ''),
            'ReviewedAt'          => opa_fmt_datetime($r['HR_Approved_DateTimeInput']),
            'Submitted'           => opa_fmt_datetime($r['DateTimeInput']),
        ];

        // Details summary — used by the list table's single "Details" column;
        // a row may show a correction, a schedule, or both.
        $detailParts = [];
        if ($hasCorrection) {
            $detailParts[] = trim(($row['ShiftPart'] ?: '—') . ' ' . ($row['Direction'] ?: '') . ': '
                . ($row['OriginalTime'] ?: '—') . ' → ' . ($row['CorrectedTime'] ?: '—'));
        }
        if ($hasSchedule) {
            $schedBits = [];
            if ($row['ScheduleAmIn'])  $schedBits[] = 'AM In ' . $row['ScheduleAmIn'];
            if ($row['ScheduleAmOut']) $schedBits[] = 'AM Out ' . $row['ScheduleAmOut'];
            if ($row['SchedulePmIn'])  $schedBits[] = 'PM In ' . $row['SchedulePmIn'];
            if ($row['SchedulePmOut']) $schedBits[] = 'PM Out ' . $row['SchedulePmOut'];
            $detailParts[] = implode(', ', $schedBits);
        }
        $row['Details'] = $detailParts ? implode(' · ', $detailParts) : '—';

        $rows[] = $row;
    }

    echo json_encode(['success' => true, 'overrides' => $rows]);
    exit;
}

if ($action === 'get_counts') {

    $sql = "SELECT [HR_Status], COUNT(*) AS Cnt
            FROM [dbo].[TBL_Attendance_Override]
            GROUP BY [HR_Status]";

    $stmt = sqlsrv_query($conn, $sql);

    if ($stmt === false) {
        echo json_encode(['success' => false, 'message' => 'Query error.', 'errors' => sqlsrv_errors()]);
        exit;
    }

    $counts = ['pending' => 0, 'approved' => 0, 'rejected' => 0];
    $map = [0 => 'pending', 1 => 'approved', 2 => 'rejected'];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $key = $map[(int)($row['HR_Status'] ?? -1)] ?? null;
        if ($key !== null) $counts[$key] = (int)$row['Cnt'];
    }

    echo json_encode(['success' => true, 'counts' => $counts]);
    exit;
}

// Same lookups as override-attendance-ajax.php, duplicated here since this
// is a separate RBAC module — the modal's Category/Type dropdowns need them.
if ($action === 'get_override_categories') {

    $sql = "SELECT [OverrideID], [Override_Name]
            FROM [dbo].[Tbl_Override_Category]
            WHERE [Status] = 1
            ORDER BY [Override_Name] ASC";

    $stmt = sqlsrv_query($conn, $sql);

    if ($stmt === false) {
        echo json_encode(['success' => false, 'message' => 'Query error.', 'errors' => sqlsrv_errors()]);
        exit;
    }

    $results = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $results[] = ['OverrideID' => $row['OverrideID'], 'Override_Name' => trim($row['Override_Name'])];
    }

    echo json_encode(['success' => true, 'categories' => $results]);
    exit;
}

if ($action === 'get_override_types') {

    $sql = "SELECT [TypeID], [Category], [Type_Name]
            FROM [dbo].[Tbl_Override_Type]
            WHERE [Status] = 1
            ORDER BY [Type_Name] ASC";

    $stmt = sqlsrv_query($conn, $sql);

    if ($stmt === false) {
        echo json_encode(['success' => false, 'message' => 'Query error.', 'errors' => sqlsrv_errors()]);
        exit;
    }

    $results = [];
    while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
        $results[] = ['TypeID' => $row['TypeID'], 'Category' => trim($row['Category'] ?? ''), 'Type_Name' => trim($row['Type_Name'])];
    }

    echo json_encode(['success' => true, 'types' => $results]);
    exit;
}

if ($action === 'update_override' || $action === 'approve_override' || $action === 'reject_override') {

    // Mutating action — enforce full (not view-only) access and verify CSRF
    rbac_enforce_full_access('override_attendance_approval', true);
    rbac_csrf_verify();

    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid override ID.']);
        exit;
    }

    $rowKind = opa_row_kind($conn, $id);
    if ($rowKind === null) {
        echo json_encode(['success' => false, 'message' => 'Override not found.']);
        exit;
    }

    $overrideType = trim($_POST['override_type'] ?? '');
    $remarks      = trim($_POST['remarks'] ?? '');
    $reviewer     = opa_reviewer_id();

    // The review modal always shows both the point-correction fields and the
    // schedule fields together (mirroring the single merged submission form),
    // so both groups get written here based on whatever the reviewer left
    // filled in — not on the row's original kind. This lets HR add a schedule
    // to a correction-only row (or vice versa) while editing, same as the
    // employee could have on submission.
    $correctedTime = trim($_POST['corrected_time'] ?? '');
    $amIn  = trim($_POST['sched_am_in']  ?? '');
    $amOut = trim($_POST['sched_am_out'] ?? '');
    $pmIn  = trim($_POST['sched_pm_in']  ?? '');
    $pmOut = trim($_POST['sched_pm_out'] ?? '');
    $anyCorrection = $correctedTime !== '';
    $anySchedule   = $amIn !== '' || $amOut !== '' || $pmIn !== '' || $pmOut !== '';

    if ($action !== 'update_override' && !$anyCorrection && !$anySchedule) {
        echo json_encode(['success' => false, 'message' => 'Fill in a Corrected Time and/or at least one Shift Time (AM/PM In/Out).']);
        exit;
    }
    if ($action !== 'update_override' && $overrideType === '') {
        echo json_encode(['success' => false, 'message' => 'Override Type is required.']);
        exit;
    }

    $setClauses = [
        "[ATime] = ?", "[SetTime] = ?", "[SetTimeOutAM] = ?", "[SetTimeInPM] = ?", "[SetTimeOutPM] = ?",
        "[Override_Type] = ?", "[Remarks] = ?",
    ];
    $params = [
        $correctedTime ?: null, $amIn ?: null, $amOut ?: null, $pmIn ?: null, $pmOut ?: null,
        $overrideType, $remarks,
    ];

    if ($action === 'approve_override' || $action === 'reject_override') {
        $newStatus = $action === 'approve_override' ? 1 : 2;
        $setClauses[] = "[HR_Status] = ?";
        $setClauses[] = "[HR_EmployeeID] = ?";
        $setClauses[] = "[HR_Approved_DateTimeInput] = GETDATE()";
        $params[] = $newStatus;
        $params[] = $reviewer;
    }

    $params[] = $id;

    // Approve/Reject only ever act on a still-Pending row (guarded here),
    // same as before — prevents two HR users double-deciding the same row.
    // Save Changes (update_override) has no such guard: editing a typo on
    // an already-Approved/Rejected row is allowed, and — because the view
    // chain queries TBL_Attendance_Override live — editing ATime (or
    // SetTime/SetTimeOutAM/SetTimeInPM/SetTimeOutPM) on an Approved row
    // will immediately change what shows in attendance.
    $statusGuard = ($action === 'approve_override' || $action === 'reject_override') ? ' AND [HR_Status] = 0' : '';

    $sql = "UPDATE [dbo].[TBL_Attendance_Override] SET " . implode(', ', $setClauses) . " WHERE [ID] = ?" . $statusGuard;

    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt === false) {
        echo json_encode(['success' => false, 'message' => 'Update error.', 'errors' => sqlsrv_errors()]);
        exit;
    }

    if (($action === 'approve_override' || $action === 'reject_override') && sqlsrv_rows_affected($stmt) === 0) {
        echo json_encode(['success' => false, 'message' => 'This override was already reviewed by someone else. Refresh the list.']);
        exit;
    }

    $messages = [
        'update_override'  => 'Changes saved.',
        'approve_override' => 'Override approved. It now reflects in the employee\'s attendance record.',
        'reject_override'  => 'Override rejected.',
    ];

    echo json_encode(['success' => true, 'message' => $messages[$action]]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Unknown action.']);