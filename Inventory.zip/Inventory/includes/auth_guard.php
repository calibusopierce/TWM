<?php
/**
 * auth_guard.php
 * Checked at the very top of every page (via session_guard.php for
 * inner Warehouse/Technical pages, and directly by the root
 * index.php). If nobody's logged in, redirects to login.php and
 * carries the originally-requested URL along so login can send them
 * back where they meant to go.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['logged_in'])) {
    // Root pages (index.php) sit next to login.php directly; inner
    // pages live one folder down (warehouse/, technical/) and need
    // to reach up to it.
    $scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
    $isInnerPage = (strpos($scriptPath, '/technical/') !== false) || (strpos($scriptPath, '/warehouse/') !== false);
    $loginPath = $isInnerPage ? '../login.php' : 'login.php';

    $redirectTo = $_SERVER['REQUEST_URI'] ?? '';
    $target = $loginPath . ($redirectTo ? '?redirect=' . urlencode($redirectTo) : '');

    header('Location: ' . $target);
    exit;
}

if (!function_exists('getUserInitials')) {
    function getUserInitials() {
        $name = trim($_SESSION['display_name'] ?? $_SESSION['username'] ?? '');
        if ($name === '') return '?';
        $words = preg_split('/\s+/', $name);
        $initials = strtoupper(substr($words[0], 0, 1) . (isset($words[1]) ? substr($words[1], 0, 1) : ''));
        return $initials !== '' ? $initials : '?';
    }
}
