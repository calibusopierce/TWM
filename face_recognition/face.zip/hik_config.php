<?php
// ══════════════════════════════════════════════════════════════════════════════
// hik_config.php — Hikvision device credentials
// Keep this file OUT of version control and blocked via .htaccess (see below).
// ══════════════════════════════════════════════════════════════════════════════

define('HIKVISION_IP', '192.168.100.59');
define('HIKVISION_PORT', '80');
define('HIKVISION_USERNAME', 'admin');
define('HIKVISION_PASSWORD', 'twm88888');
